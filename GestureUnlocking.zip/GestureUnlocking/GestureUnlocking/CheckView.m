//
//  CheckView.m
//  GestureUnlocking
//
//  Created by imac on 16/1/14.
//  Copyright © 2016年 imac. All rights reserved.
//

#import "CheckView.h"

@implementation CheckView

-(instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        
        self.userInteractionEnabled = YES;
        
    }


    return self;

}





@end
