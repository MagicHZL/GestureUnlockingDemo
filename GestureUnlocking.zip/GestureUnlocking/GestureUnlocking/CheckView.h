//
//  CheckView.h
//  GestureUnlocking
//
//  Created by imac on 16/1/14.
//  Copyright © 2016年 imac. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CheckView : UIImageView

@property(nonatomic,assign)int s;//标记的密码符

@end
